package com.hsm.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import com.hsm.service.PatientService;
import com.hsm.entity.Appointment;
import com.hsm.entity.Doctor;
import com.hsm.entity.Patient;
import com.hsm.exception.DoctorNotFoundException;
import com.hsm.service.DoctorService;

@RestController
@RequestMapping("/doctor")
@CrossOrigin("*")
public class DoctorController {
    @Autowired
    private DoctorService doctorService;

    // POST Request to generate a bill for a patient
    @PostMapping("/add")
    public ResponseEntity<Doctor> addDoctor(@RequestBody Doctor doctor) {
    	System.out.println(doctor);
        Doctor newDoctor = doctorService.addDoctor(doctor);
        return new ResponseEntity<>(newDoctor, HttpStatus.CREATED);
    }
    @PostMapping("login/add")
    public ResponseEntity<Doctor> loginaddDoctor(@RequestBody Doctor doctor) {
    	System.out.println("inside doctor login" + doctor);
        Doctor newDoctor = doctorService.findDoctorByEmailAndPassword(doctor);
        return new ResponseEntity<Doctor>(newDoctor, HttpStatus.OK);
    }

    @GetMapping("/{id}")
    public Doctor getDoctorById(@PathVariable(value = "id") long id) {
        Doctor doctor = doctorService.getDoctorById(id);
        if (doctor == null) {
            throw new DoctorNotFoundException("Doctor with ID " + id + " not found");
        }
        return doctor;
    }
    @PutMapping("/update/{doctorid}")
    public Doctor updateDoctorList(@PathVariable Long doctorid, @RequestBody Doctor updateDoctor) {
    	updateDoctor.setDoctorId(doctorid);
        return doctorService.updateDoctorList(updateDoctor);
    }
    
    @DeleteMapping("/doctordelete/{id}")
    public void deletDoctor(@PathVariable long id) {
    	doctorService.deleteDoctor(id);
    }

    
    //list of all patient
    @GetMapping("/doctorlist")
    public List<Doctor> getAllDoctors() {
        return doctorService.getAllDoctors();
    }
  
}