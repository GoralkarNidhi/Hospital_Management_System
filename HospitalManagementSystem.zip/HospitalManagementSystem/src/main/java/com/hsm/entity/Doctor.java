package com.hsm.entity;

import java.util.List;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;


@Entity
@Table(name = "DoctorMaster")
public class Doctor {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "doctorId")
    private long doctorId;
    
    @Column(name = "doctname")
    private String doctName;

    @Column(name = "password")
    private String password;

    
    @Column(name = "email",unique=true)
    private String email;

    @Column(name = "specialization")
    private String specialization;

    @Column(name = "education")
    private String education;
    
    private String mobileNo;
    private String gender;
    private String department;
    

    @ManyToMany(mappedBy = "doctors")
    private List<Patient> patients;

    public Doctor() {
        super();
    }

  
	public Doctor(long doctorId, String doctName, String password, String email, String specialization,
			String education,String mobileNo, String gender, String department, 
			List<Patient> patients) {
		super();
		this.doctorId = doctorId;
		this.doctName = doctName;
		this.password = password;
		this.email = email;
		this.specialization = specialization;
		this.education = education;
		
		this.mobileNo = mobileNo;
		this.gender = gender;
		this.department = department;
		
		this.patients = patients;
	}


	public long getDoctorId() {
		return doctorId;
	}

	public void setDoctorId(long doctorId) {
		this.doctorId = doctorId;
	}

	public String getDoctName() {
		return doctName;
	}

	public void setDoctName(String doctName) {
		this.doctName = doctName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getSpecialization() {
		return specialization;
	}

	public void setSpecialization(String specialization) {
		this.specialization = specialization;
	}

	public String getEducation() {
		return education;
	}

	public void setEducation(String education) {
		this.education = education;
	}


	
	
	public String getMobileNo() {
		return mobileNo;
	}


	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}


	public String getGender() {
		return gender;
	}


	public void setGender(String gender) {
		this.gender = gender;
	}


	public String getDepartment() {
		return department;
	}


	public void setDepartment(String department) {
		this.department = department;
	}


	public List<Patient> getPatients() {
		return patients;
	}


	public void setPatients(List<Patient> patients) {
		this.patients = patients;
	}


	@Override
	public String toString() {
		return "Doctor [doctorId=" + doctorId + ", doctName=" + doctName + ", password=" + password + ", email=" + email
				+ ", specialization=" + specialization + ", education=" + education + ", mobileNo=" + mobileNo
				+ ", gender=" + gender + ", department=" + department + ", admin=" +  ", patients=" + patients
				+ "]";
	}


	
	

}


