package com.hsm.entity;

import java.util.Date;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name = "appointment")
public class Appointment {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	
	private Long appointmentId;
	private String fullName;
	private String address;
	private String department;
	private String doctName;
	private String emailId;
	private String mobileNo;
	private String patientType;
	private Date date;
	private long doctorId;
	




	public Appointment() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Appointment(Long appointmentId, String fullName, String address, String department, String doctName,
			String emailId, String mobileNo, String patientType, Date date, Doctor doctor, Patient patient, long doctorId) {
		super();
		this.appointmentId = appointmentId;
		this.fullName = fullName;
		this.address = address;
		this.department = department;
		this.doctName = doctName;
		this.emailId = emailId;
		this.mobileNo = mobileNo;
		this.patientType = patientType;
		this.date = date;
	
		this.doctorId = doctorId;
	}

	public Long getAppointmentId() {
		return appointmentId;
	}

	public void setAppointmentId(Long appointmentId) {
		this.appointmentId = appointmentId;
	}

	public String getFullName() {
		return fullName;
	}

	public void setFullName(String fullName) {
		this.fullName = fullName;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getDepartment() {
		return department;
	}

	public void setDepartment(String department) {
		this.department = department;
	}

	public String getDoctorName() {
		return doctName;
	}

	
	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}

	public String getPatientType() {
		return patientType;
	}

	public void setPatientType(String patientType) {
		this.patientType = patientType;
	}

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	

	public String getDoctName() {
		return doctName;
	}

	public void setDoctName(String doctName) {
		this.doctName = doctName;
	}

	public long getDoctorId() {
		return doctorId;
	}

	public void setDoctorId(long doctorId) {
		this.doctorId = doctorId;
	}

	@Override
	public String toString() {
		return "Appointment [appointmentId=" + appointmentId + ", fullName=" + fullName + ", address=" + address
				+ ", department=" + department + ", doctName=" + doctName + ", emailId=" + emailId + ", mobileNo="
				+ mobileNo + ", patientType=" + patientType + ", date=" + date + ", doctorId=" + doctorId + "]";
	}

	

	

}
