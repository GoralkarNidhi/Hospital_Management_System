package com.hsm.entity;

import java.util.List;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;


@Entity
@Table(name = "AdminMaster")
public class Admin {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	
	private Long adminId;
	private String userName;
	private String password;
	


    @OneToMany(mappedBy = "admin")
    private List<Patient> patients;
    
	public Admin() {
		super();
		// TODO Auto-generated constructor stub
	}


	
	public Admin(Long adminId, String userName, String password, List<Doctor> doctors, List<Patient> patients) {
		super();
		this.adminId = adminId;
		this.userName = userName;
		this.password = password;
	
		this.patients = patients;
	}



	public Long getAdminId() {
		return adminId;
	}

	public void setAdminId(Long adminId) {
		this.adminId = adminId;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	
	
	public List<Patient> getPatients() {
		return patients;
	}

	public void setPatients(List<Patient> patients) {
		this.patients = patients;
	}

	@Override
	public String toString() {
		return "Admin [adminId=" + adminId + ", userName=" + userName + ", password=" + password + ", doctors="
				+ ", patients=" + patients + "]";
	}




}
