package com.hsm.entity;

import java.util.List;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.JoinTable;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name = "patientragistration")
public class Patient {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long patientId;
	private String fullName;
	@Column(unique=true)
	private String emailId;
	private String mobileNo;
	private String gender;
	private int age;
	private String password;
	private String patientType;
	private String doctType;
	
	 @ManyToOne
	    @JoinColumn(name = "admin_id")
	    private Admin admin;

	    @ManyToMany
	    @JoinTable(
	        name = "PatientDoctor",
	        joinColumns = @JoinColumn(name = "patient_id"),
	        inverseJoinColumns = @JoinColumn(name = "doctor_id")
	    )
	    private List<Doctor> doctors;
	  
	    
	public Patient() {
		super();
		// TODO Auto-generated constructor stub
	}

	

	public Patient(long patientId, String fullName, String emailId, String mobileNo, String gender, int age,
			String password, Admin admin, List<Doctor> doctors, String patientType, String doctType) {
		super();
		this.patientId = patientId;
		this.fullName = fullName;
		this.emailId = emailId;
		this.mobileNo = mobileNo;
		this.gender = gender;
		this.age = age;
		this.password = password;
		this.admin = admin;
		this.doctors = doctors;
		this.patientType = patientType;
	}



	public long getPatientId() {
		return patientId;
	}

	public void setPatientId(long patientId) {
		this.patientId = patientId;
	}

	public String getFullName() {
		return fullName;
	}

	public void setFullName(String fullName) {
		this.fullName = fullName;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}
	

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}



	public Admin getAdmin() {
		return admin;
	}



	public void setAdmin(Admin admin) {
		this.admin = admin;
	}



	public List<Doctor> getDoctors() {
		return doctors;
	}



	public void setDoctors(List<Doctor> doctors) {
		this.doctors = doctors;
	}



	public String getPatientType() {
		return patientType;
	}



	public void setPatientType(String patientType) {
		this.patientType = patientType;
	}



	public String getDoctType() {
		return doctType;
	}



	public void setDoctType(String doctType) {
		this.doctType = doctType;
	}



	@Override
	public String toString() {
		return "Patient [patientId=" + patientId + ", fullName=" + fullName + ", emailId=" + emailId + ", mobileNo="
				+ mobileNo + ", gender=" + gender + ", age=" + age + ", password=" + password + ", patientType="
				+ patientType + ", doctType=" + doctType + ", admin=" + admin + ", doctors=" + doctors + "]";
	}





	
}
