package com.hsm.service;

import java.util.List;

import com.hsm.entity.Patient;

public interface PatientService {

	public List<Patient> getPatient();
	
	Patient getPatientById(long id);

    void addPatient(Patient patient);
    
    void loginPatient(Patient patient);

    void updatePatient(Patient patient);

    void deletePatient(long id);

    void loginPatient(String email, String password);
    
    Patient findByEmailIdAndPassword(Patient patient);

}
