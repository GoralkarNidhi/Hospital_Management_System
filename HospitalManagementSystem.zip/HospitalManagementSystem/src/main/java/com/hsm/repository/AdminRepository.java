package com.hsm.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.hsm.entity.Admin;
import com.hsm.entity.Doctor;

//Create a repository interface for your Admin entity by extending the JpaRepository interface.
//This interface will provide basic CRUD operations for your entity.
//entity => repository => controller

public interface AdminRepository extends JpaRepository<Admin, Long> {
	Admin findByUserNameAndPassword(String userName, String password);
	

}
