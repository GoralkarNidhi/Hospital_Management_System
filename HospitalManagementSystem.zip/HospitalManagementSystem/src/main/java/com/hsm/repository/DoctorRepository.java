package com.hsm.repository;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import com.hsm.entity.Doctor;

public interface DoctorRepository extends JpaRepository<Doctor, Long> {
    // You can add custom query methods here if needed
	        
	       /* default List<Doctor> addDoctors(List<Doctor> doctors) {
	            return saveAll(doctors);
	    }*/
	Doctor findByEmailAndPassword(String email, String password);
}
